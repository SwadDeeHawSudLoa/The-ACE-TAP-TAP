package com.example.mytermproject;

import android.provider.BaseColumns;

public interface Constants extends BaseColumns {
    public static final String TABLE_NAME = "ScoreBoard";
    public static final String DATE = "date";
    public static final String scoreTap = "TAP";
    public static final String LEVEL = "level";

}
